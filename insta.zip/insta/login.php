<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
<div class="wrapper">
        <div class="logo">
            <img src="img/logo.jpeg" alt="">
        </div>
        <br><br>
        <div class="text-center mt-4 name">
            INSTA PURBALINGGA
        </div><br>
    <form action="proses_login.php" method="post" class="p-3 mt-3">
    <div class="form-field d-flex align-items-center">
                <span class="far fa-user"></span>
        <input type="text" name="username" id="" placeholder="Username">
        </div>
        <div class="form-field d-flex align-items-center">
                <span class="fas fa-key"></span>
        <input type="password" name="password" id="" placeholder="Password">
        </div>
        <button type="submit" value="login" class="btn mt-3" style="background-color: black;">login</button>
    </form>
</body>
</html>